#!/bin/bash
pio run -c platformio.ini -d .
