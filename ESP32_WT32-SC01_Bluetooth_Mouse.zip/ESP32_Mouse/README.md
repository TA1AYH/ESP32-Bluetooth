# WT32-SC01-Exp
Experiment with WT32-SC01 getting touch and rendering to work - not clever, not pretty but works! :)

Now uses platformio as using the Arduino IDE was causing folks too many issues.

# Building

* If you're using vscode, install platformio extension and build and upload.

* If you're using platformio on the command line, examples for building and uploaded provided in build.sh/upload.sh
